-- =====================================================================
-- SOUR Billing — Supabase schema
-- Run this whole file once in Supabase: SQL Editor > New query > Run.
-- Safe to re-run: it creates what's missing and replaces functions.
-- =====================================================================

create extension if not exists pgcrypto;

-- ---------- tables ----------
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  name text,
  role text not null default 'staff' check (role in ('owner','staff')),
  active boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.store (
  id int primary key default 1 check (id = 1),
  data jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);
insert into public.store (id, data) values (1,
  '{"settings":{"storeName":"SOUR","invoicePrefix":"SOUR-","footer":"Thank you for shopping with us.","address":"","phone":"","upi":"","logo":""},"seq":0,"setup":false,"sample":false,"staffCanDiscount":false,"theme":{}}'::jsonb)
on conflict (id) do nothing;

create table if not exists public.products  (id text primary key, data jsonb not null, updated_at timestamptz not null default now());
create table if not exists public.discounts (id text primary key, data jsonb not null, updated_at timestamptz not null default now());
create table if not exists public.expenses  (id text primary key, data jsonb not null, updated_at timestamptz not null default now());
create table if not exists public.capital   (id text primary key, data jsonb not null, updated_at timestamptz not null default now());
create table if not exists public.payments  (id text primary key, data jsonb not null, updated_at timestamptz not null default now());
create table if not exists public.sales (
  id text primary key,
  data jsonb not null,
  created_by uuid references public.profiles(id) on delete set null default auth.uid(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists sales_created_at_idx on public.sales (created_at desc);
create table if not exists public.inventory_history (
  id bigserial primary key,
  t timestamptz not null default now(),
  v numeric not null
);

-- ---------- role helpers ----------
create or replace function public.is_member() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce((select active from public.profiles where id = auth.uid()), false)
$$;

create or replace function public.is_owner() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce((select role = 'owner' and active from public.profiles where id = auth.uid()), false)
$$;

-- First account ever becomes the owner. Every later sign-up starts as an
-- inactive staff account until the owner switches it on.
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
declare first_user boolean;
begin
  perform pg_advisory_xact_lock(424242);
  select not exists (select 1 from public.profiles) into first_user;
  insert into public.profiles (id, email, name, role, active)
  values (new.id, new.email,
          coalesce(nullif(new.raw_user_meta_data->>'name',''), split_part(new.email,'@',1)),
          case when first_user then 'owner' else 'staff' end,
          first_user)
  on conflict (id) do nothing;
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- Never allow the last active owner to be demoted or switched off.
create or replace function public.protect_last_owner() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if old.role = 'owner' and old.active and (new.role <> 'owner' or not new.active) then
    if (select count(*) from public.profiles where role = 'owner' and active and id <> old.id) = 0 then
      raise exception 'Keep at least one active owner.';
    end if;
  end if;
  new.id := old.id;
  new.email := old.email;
  return new;
end $$;

drop trigger if exists profiles_protect_owner on public.profiles;
create trigger profiles_protect_owner before update on public.profiles
  for each row execute function public.protect_last_owner();

-- ---------- row level security ----------
alter table public.profiles          enable row level security;
alter table public.store             enable row level security;
alter table public.products          enable row level security;
alter table public.discounts         enable row level security;
alter table public.expenses          enable row level security;
alter table public.capital           enable row level security;
alter table public.payments          enable row level security;
alter table public.sales             enable row level security;
alter table public.inventory_history enable row level security;

do $$
declare r record;
begin
  -- drop old policies so the file can be re-run cleanly
  for r in select policyname, tablename from pg_policies
           where schemaname = 'public'
             and tablename = any (array['profiles','store','products','discounts','expenses','capital','payments','sales','inventory_history'])
  loop
    execute format('drop policy if exists %I on public.%I;', r.policyname, r.tablename);
  end loop;
end $$;

create policy profiles_read   on public.profiles for select using (id = auth.uid() or public.is_owner());
create policy profiles_update on public.profiles for update using (public.is_owner()) with check (public.is_owner());

create policy store_read  on public.store for select using (public.is_member());
create policy store_owner on public.store for all    using (public.is_owner()) with check (public.is_owner());

create policy discounts_read on public.discounts for select using (public.is_member());

do $$
declare t text;
begin
  for t in select unnest(array['products','discounts','expenses','capital','payments','sales','inventory_history']) loop
    execute format('create policy %I on public.%I for all using (public.is_owner()) with check (public.is_owner());', t || '_owner', t);
  end loop;
end $$;

-- ---------- functions the app calls ----------

-- Login screen: is there an owner yet, and what does the store look like?
create or replace function public.has_owner() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles where role = 'owner')
$$;

create or replace function public.public_brand() returns jsonb
language sql stable security definer set search_path = public as $$
  select jsonb_build_object(
    'storeName', data->'settings'->>'storeName',
    'logo',      data->'settings'->>'logo',
    'theme',     coalesce(data->'theme','{}'::jsonb))
  from public.store where id = 1
$$;

-- Staff see the catalogue without landing cost.
create or replace function public.staff_catalog() returns table (id text, data jsonb)
language sql stable security definer set search_path = public as $$
  select p.id, p.data - 'cost'
  from public.products p
  where public.is_member() and coalesce(p.data->>'status','active') <> 'inactive'
$$;

-- Light stock refresh after each sale (sizes only, no images).
create or replace function public.catalog_stock() returns table (id text, sizes jsonb)
language sql stable security definer set search_path = public as $$
  select p.id, p.data->'sizes' from public.products p where public.is_member()
$$;

-- Phone autocomplete at the counter.
create or replace function public.customer_lookup(q text) returns table (phone text, name text, orders bigint)
language sql stable security definer set search_path = public as $$
  select s.data->>'customerPhone' as phone,
         (array_agg(s.data->>'customerName' order by s.created_at desc)
            filter (where coalesce(s.data->>'customerName','') <> ''))[1] as name,
         count(*) as orders
  from public.sales s
  where public.is_member()
    and length(regexp_replace(coalesce(q,''), '\D', '', 'g')) >= 3
    and regexp_replace(coalesce(s.data->>'customerPhone',''), '\D', '', 'g')
        like '%' || regexp_replace(q, '\D', '', 'g') || '%'
  group by 1
  order by count(*) desc
  limit 5
$$;

-- Owner store updates. The invoice counter (seq) can only change through
-- create_sale, or when the owner deliberately resets it.
create or replace function public.save_store(patch jsonb, reset_seq int default null) returns jsonb
language plpgsql security definer set search_path = public as $$
declare d jsonb;
begin
  if not public.is_owner() then raise exception 'Only the owner can change store settings.'; end if;
  update public.store
     set data = case when reset_seq is null then data || (patch - 'seq')
                     else (data || (patch - 'seq')) || jsonb_build_object('seq', reset_seq) end,
         updated_at = now()
   where id = 1
  returning data into d;
  return d;
end $$;

-- The one way a bill is created. Prices, offers, stock and the invoice
-- number are all decided here on the server, so nothing typed into the
-- browser can change what a product costs or sell stock that isn't there.
create or replace function public.create_sale(p jsonb) returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  me public.profiles%rowtype;
  st jsonb; it jsonb; prod jsonb; d record;
  idx int; cur int; q int; seq int;
  price numeric; cost numeric; disc numeric; remaining numeric; dval numeric; lt numeric;
  items jsonb := '[]'::jsonb;
  sub numeric := 0; auto numeric := 0; tcost numeric := 0;
  manual numeric; ship numeric; pt numeric;
  inv text; sid text; pid text; sale jsonb;
  today date := (now() at time zone 'Asia/Kolkata')::date;
begin
  select * into me from public.profiles where id = auth.uid() and active;
  if not found then raise exception 'Your account isn''t active. Ask the owner for access.'; end if;
  if jsonb_typeof(p->'items') <> 'array' or jsonb_array_length(p->'items') = 0 then
    raise exception 'Add at least one item to the bill.';
  end if;

  select data into st from public.store where id = 1 for update;

  for it in select * from jsonb_array_elements(p->'items') loop
    q := (it->>'qty')::int;
    if q is null or q < 1 or q > 999 then raise exception 'One of the quantities isn''t valid.'; end if;

    select data into prod from public.products where id = it->>'productId' for update;
    if prod is null then raise exception 'A product in this bill no longer exists.'; end if;

    idx := null; cur := null;
    select (t.ord - 1)::int, coalesce((t.elem->>'stockQty')::int, 0) into idx, cur
      from jsonb_array_elements(prod->'sizes') with ordinality as t(elem, ord)
     where t.elem->>'size' = it->>'size'
     limit 1;
    if idx is null then raise exception '% has no size %.', prod->>'name', it->>'size'; end if;
    if cur < q then raise exception 'Only % left of % in size %.', cur, prod->>'name', it->>'size'; end if;

    prod := jsonb_set(prod, array['sizes', idx::text, 'stockQty'], to_jsonb(cur - q));
    update public.products set data = prod, updated_at = now() where id = it->>'productId';

    price := coalesce((prod->>'price')::numeric, 0);
    cost  := coalesce((prod->>'cost')::numeric, 0);
    disc  := price * coalesce((prod->>'discountPct')::numeric, 0) / 100;

    for d in
      select x.data from public.discounts x
       where coalesce((x.data->>'active')::boolean, false)
         and (coalesce(x.data->>'from','') = '' or (x.data->>'from')::date <= today)
         and (coalesce(x.data->>'to','')   = '' or (x.data->>'to')::date   >= today)
         and (jsonb_array_length(coalesce(x.data->'products','[]'::jsonb)) = 0
              or (x.data->'products') ? (it->>'productId'))
    loop
      remaining := price - disc;
      dval := coalesce((d.data->>'value')::numeric, 0);
      if d.data->>'type' = 'pct' then disc := disc + remaining * dval / 100;
      else disc := disc + least(dval, remaining); end if;
    end loop;

    disc := least(round(disc, 2), price);
    lt := round((price - disc) * q, 2);
    sub := sub + price * q; auto := auto + disc * q; tcost := tcost + cost * q;

    items := items || jsonb_build_array(jsonb_build_object(
      'productId', it->>'productId', 'name', prod->>'name', 'sku', prod->>'sku', 'size', it->>'size',
      'unitPrice', price, 'unitCost', cost, 'qty', q, 'discount', round(disc * q, 2),
      'lineTotal', lt, 'lineProfit', round(lt - cost * q, 2)));
  end loop;

  manual := greatest(coalesce((p->>'manualDiscount')::numeric, 0), 0);
  if manual > 0 and me.role <> 'owner' and not coalesce((st->>'staffCanDiscount')::boolean, false) then
    raise exception 'Extra discounts need the owner. Remove it or ask the owner to allow staff discounts.';
  end if;
  manual := least(manual, round(sub - auto, 2));
  ship   := greatest(coalesce((p->>'shippingCharge')::numeric, 0), 0);
  pt     := round(sub - auto - manual, 2);

  seq := coalesce((st->>'seq')::int, 0) + 1;
  inv := coalesce(st->'settings'->>'invoicePrefix', '') || lpad(seq::text, 4, '0');
  update public.store set data = jsonb_set(data, '{seq}', to_jsonb(seq)), updated_at = now() where id = 1;

  sid := 's' || replace(gen_random_uuid()::text, '-', '');
  sale := jsonb_build_object(
    'id', sid, 'invoiceNumber', inv, 'date', to_jsonb(now()),
    'customerName', coalesce(p->>'customerName',''), 'customerPhone', coalesce(p->>'customerPhone',''),
    'items', items, 'subtotal', round(sub, 2), 'autoDiscountTotal', round(auto, 2),
    'manualDiscount', manual, 'productTotal', pt, 'shippingCharge', ship, 'amountPaid', pt + ship,
    'profitTotal', round(pt - tcost, 2),
    'paymentMethod', coalesce(nullif(p->>'paymentMethod',''), 'Cash'),
    'paymentStatus', case when p->>'paymentStatus' = 'Unpaid' then 'Unpaid' else 'Paid' end,
    'processedBy', jsonb_build_object('id', me.id, 'name', me.name));
  insert into public.sales (id, data, created_by) values (sid, sale, me.id);

  if sale->>'paymentStatus' = 'Unpaid' then
    pid := 'pp' || replace(gen_random_uuid()::text, '-', '');
    insert into public.payments (id, data) values (pid, jsonb_build_object(
      'id', pid, 'type', 'receivable',
      'party', coalesce(nullif(sale->>'customerName',''), 'Walk-in customer'),
      'amount', pt + ship, 'due', to_char(today + 7, 'YYYY-MM-DD'), 'note', 'Bill ' || inv,
      'status', 'pending', 'saleId', sid, 'createdAt', to_jsonb(now())));
  end if;

  insert into public.inventory_history (v)
  select coalesce(sum(
           (select coalesce(sum((e->>'stockQty')::numeric), 0) from jsonb_array_elements(pr.data->'sizes') e)
           * coalesce((pr.data->>'cost')::numeric, 0)), 0)
    from public.products pr;

  if me.role = 'owner' then return sale; end if;
  -- staff never receive cost or profit figures
  return (sale - 'profitTotal') || jsonb_build_object('items',
    (select jsonb_agg(i - 'unitCost' - 'lineProfit') from jsonb_array_elements(sale->'items') i));
end $$;

-- ---------- permissions ----------
revoke all on function public.create_sale(jsonb)               from public, anon;
revoke all on function public.save_store(jsonb, int)           from public, anon;
revoke all on function public.staff_catalog()                  from public, anon;
revoke all on function public.catalog_stock()                  from public, anon;
revoke all on function public.customer_lookup(text)            from public, anon;
grant execute on function public.create_sale(jsonb)            to authenticated;
grant execute on function public.save_store(jsonb, int)        to authenticated;
grant execute on function public.staff_catalog()               to authenticated;
grant execute on function public.catalog_stock()               to authenticated;
grant execute on function public.customer_lookup(text)         to authenticated;
grant execute on function public.has_owner()                   to anon, authenticated;
grant execute on function public.public_brand()                to anon, authenticated;

-- ---------- live updates for the owner's screens ----------
do $$
declare t text;
begin
  for t in select unnest(array['sales','products','payments','discounts']) loop
    begin
      execute format('alter publication supabase_realtime add table public.%I;', t);
    exception when duplicate_object then null;
    end;
  end loop;
end $$;

-- ---------- image storage (product photos and logo) ----------
insert into storage.buckets (id, name, public) values ('sour-images', 'sour-images', true)
on conflict (id) do nothing;

drop policy if exists sour_images_owner_insert on storage.objects;
drop policy if exists sour_images_owner_update on storage.objects;
drop policy if exists sour_images_owner_delete on storage.objects;
create policy sour_images_owner_insert on storage.objects for insert to authenticated
  with check (bucket_id = 'sour-images' and public.is_owner());
create policy sour_images_owner_update on storage.objects for update to authenticated
  using (bucket_id = 'sour-images' and public.is_owner());
create policy sour_images_owner_delete on storage.objects for delete to authenticated
  using (bucket_id = 'sour-images' and public.is_owner());

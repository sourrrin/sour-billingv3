# SOUR Billing — hosting guide

Your own billing app with an **Admin** login (everything) and **Staff** logins (billing only).
It runs on two free services:

- **Supabase**: the database and logins. Your data lives here.
- **Netlify**: hosts the app at a web address, which can be your own domain.

There's no build step and no code to run on your computer. Setup takes about 20 minutes.

```
sour-billing/
├── public/            ← this folder goes on Netlify
│   ├── index.html     the app
│   ├── config.js      your Supabase connection (you edit this)
│   └── _headers       security headers
└── supabase/
    └── schema.sql     run once in Supabase
```

---

## 1. Create the database (Supabase)

1. Go to **supabase.com** and sign up. Create a **New project**.
   - Region: choose **Mumbai (ap-south-1)**. It's closest to Coimbatore, so the app responds fastest.
   - Save the database password somewhere safe.
2. When the project is ready, open **SQL Editor**, then **New query**.
   Paste the whole of `supabase/schema.sql` and click **Run**. It should end with "Success".
3. Open **Authentication**, then the **Email** provider settings (under Sign In / Providers).
   Turn **off** "Confirm email". This lets you create staff accounts instantly from inside the app.
4. Open **Project Settings**, then **API** (called "API Keys" or "Data API" in newer dashboards). Copy:
   - the **Project URL**, which looks like `https://abcd1234.supabase.co`
   - the **anon / public** key
5. Open `public/config.js` in any text editor and paste both values in place of the placeholders. Save the file.

> Never paste the `service_role` key anywhere in this app. It bypasses all security.

## 2. Put it online (Netlify)

1. Go to **app.netlify.com/drop** and sign up.
2. Drag the **`public`** folder onto the page. Within a few seconds you get a web address,
   for example `https://sour-billing.netlify.app`.
3. Optional: rename the site under **Site configuration**, or attach your own domain
   (e.g. `billing.sourstore.in`) under **Domain management**. HTTPS is set up automatically.
4. Back in Supabase, open **Authentication**, then **URL Configuration**, and set **Site URL** to your Netlify address.
   This makes password reset emails link to the right place.

## 3. First sign-in

1. Open your web address. You'll see **Create the owner account**.
   **Do this immediately after deploying.** The first account ever created becomes the owner.
2. Set up the store: name, phone and UPI ID. Or choose **Explore with sample data** to try everything first.
3. Go to **Team**, then **Add staff**, and create an account for each person at the counter.

## What each role can do

| | Owner | Staff |
|---|---|---|
| Billing, invoices, UPI QR | ✓ | ✓ |
| See landing cost, profit, margins | ✓ | ✗ hidden by the server |
| Extra discount at the counter | ✓ | Only if you allow it in Settings |
| Dashboard, Sales, Customers, Analytics | ✓ | ✗ |
| Products, stock, Discounts | ✓ | ✗ |
| Capital, expenses, pending payments | ✓ | ✗ |
| Team, Appearance (colours, fonts), Settings | ✓ | ✗ |

These rules are enforced **in the database**, not just hidden in the screen.

- Prices, offers and stock checks for every bill are calculated on the server.
- A staff member can't change a price, sell stock that isn't there, or read costs, even with browser developer tools.
- Two tills selling the last piece at the same moment can't both succeed.

## Everyday notes

- **Changing colours and fonts:** go to Admin, then Appearance. Pick a theme or fine-tune each colour. The contrast check warns you if text becomes hard to read. Staff see the change the next time they open the app.
- **Live updates:** the owner's screens update as staff ring up bills. Staff stock refreshes after every sale and every minute.
- **Password reset:** go to Supabase, then Authentication, then Users, then the user's menu, and choose **Send password recovery**.
- **Removing someone:** in Team, switch their access off. Their next bill is refused, and the app locks the next time they open it.
- **Unknown accounts in Team:** anyone who finds your sign-up endpoint can create an account, but it starts with **no access**. Only switch on accounts you recognise.
- **Updating the app later:** drag the new `public` folder onto Netlify again (Deploys, then drag and drop). Your data stays in Supabase and isn't touched.
- **Backups:** go to Settings and choose **Download backup** weekly. Supabase also keeps its own daily backups on paid plans.
- **Supabase free plan:** projects that get **no activity for 7 days are paused**. That won't happen if the shop bills daily. If it does pause, open the Supabase dashboard and click **Restore**. For a business-critical till, the Pro plan removes this and adds daily backups.
- **Time zone:** "today" for offers and dates is India time (Asia/Kolkata), set inside `create_sale` in `schema.sql`.

## Not included yet

- Returns and exchanges
- The AI assistant
- Camera barcode scanning (USB and Bluetooth scanners work now)
- Thermal ESC/POS printing (normal printing works)
- Shopify sync

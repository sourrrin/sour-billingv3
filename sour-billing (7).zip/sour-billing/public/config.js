// SOUR Billing — connection settings
// Paste the two values from your Supabase project (Project Settings > API).
// The anon key is meant to be public: Row Level Security in schema.sql protects your data.
// NEVER paste the service_role key here.
window.SOUR_CONFIG = {
  supabaseUrl: 'https://YOUR-PROJECT.supabase.co',
  supabaseAnonKey: 'YOUR-ANON-KEY'
};
